﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Entity.Products
{
   public class HardDrive:Product
    {
        
        public HardDrive(double price) : base(price,1.0)
        {
            
        }
    }
}
