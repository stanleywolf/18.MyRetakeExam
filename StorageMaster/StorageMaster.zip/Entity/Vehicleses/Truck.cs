﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Entity.Vehicleses
{
   public class Truck:Vehicle
    {
        public Truck() : base(5)
        {
        }
    }
}
