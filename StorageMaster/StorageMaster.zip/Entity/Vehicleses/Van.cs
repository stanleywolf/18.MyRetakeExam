﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Entity.Vehicleses
{
    public class Van:Vehicle
    {
        public Van() : base(2)
        {
        }
    }
}
